# Terrorist Creeper Resource Pack

## Overview

A Resource Pack that re-skins Minecraft Creepers to appear as Terrorists.

## Usage

This pack should not require any special installation- just [load the resource pack](https://minecraft.gamepedia.com/Tutorials/Loading_a_resource_pack) and it should load immediately.

## License

This project is licensed under the [MIT](https://github.com/TheBillyIsMe/TerroristCreeperResourcePack/blob/master/LICENSE) License © [TheBillyIsMe](https://github.com/TheBillyIsMe)
